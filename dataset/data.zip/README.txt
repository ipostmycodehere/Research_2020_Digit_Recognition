File data.npy là một ma trận (1900,10001)
Các hàng của ma trận tương ứng với một ảnh.
Cột cuối cùng thể hiện nhãn của các ảnh.
Bộ dữ liệu gồm các chữ số tách ra từ 19 ảnh lưới 10x10. Theo thứ tự trong ma trận thì cứ 100 số là cùng một ảnh.
